﻿Console.WriteLine("enter first number");
string firstInput = Console.ReadLine();
Console.WriteLine("enter second number");
string secondInput = Console.ReadLine();


Console.WriteLine("After swapping:");
Console.WriteLine("First number:" + secondInput);
Console.WriteLine("Second number:" + firstInput);