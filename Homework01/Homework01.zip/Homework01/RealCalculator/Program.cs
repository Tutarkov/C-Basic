﻿Console.WriteLine("Enter first number");
string inputNumb1 = Console.ReadLine();
Console.WriteLine("Enter second number");
string inputNumb2 = Console.ReadLine();
Console.WriteLine("Enter third number");
string inputNumb3 = Console.ReadLine();
Console.WriteLine("Enter four number");
string inputNumb4 = Console.ReadLine();

float numb1;
bool firstConvert = float.TryParse(inputNumb1, out numb1);
float numb2;
bool secondConvert = float.TryParse(inputNumb2, out numb2);
float numb3;
bool thirdConvert = float.TryParse(inputNumb3, out numb3);
float numb4;
bool fourConvert = float.TryParse(inputNumb4, out numb4);

float averige = (numb1 + numb2 + numb3 + numb4) / 4;

Console.WriteLine("averige:" + averige);

