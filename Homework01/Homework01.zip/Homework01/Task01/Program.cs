﻿Console.WriteLine("enter first number");
string firstInput = Console.ReadLine();
Console.WriteLine("Enter operation (+,-,*,/)");
string operation = Console.ReadLine();
Console.WriteLine("enter secound number");
string secondInput = Console.ReadLine();

float firstNumb;
bool firstSuccess = float.TryParse(firstInput, out firstNumb);
float secondNumb;
bool secondSuccess = float.TryParse(secondInput, out secondNumb);

float result;

if (operation == "+")
{
    result = firstNumb + secondNumb;
    Console.WriteLine(result);
}
else if(operation == "-")
{
    result = firstNumb - secondNumb;
    Console.WriteLine(result);
}
else if (operation == "*")
{
    result = firstNumb* secondNumb;
    Console.WriteLine(result);
}
else if (operation == "/")
{
    result = firstNumb / secondNumb;
    Console.WriteLine(result);
}
else
    Console.WriteLine("Operation is not true");

