﻿using System.Xml.Linq;

int[] arraySum = new int[6];

int sum = 0;

for (int i = 0; i < 6; i++)
{
    Console.Write($"Enter integer no.{i+1}:");
    arraySum[i] = int.Parse(Console.ReadLine());
}
foreach (int i in arraySum)
{
    if (i % 2 == 0)
    {
        sum = sum + i;
        //sum += i;
    }
}
Console.WriteLine("The Result is:"+sum);