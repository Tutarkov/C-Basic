﻿string[] studentsG1 = new string[] { "Ivan", "Kristijan", "Viki", "Stefan", "Pavle" };
string[] studentsG2 = new string[] { "Angel", "Brane", "Cece", "Sara", "Dule" };

Console.WriteLine("enter numb of group (1 or 2 )");
string students = Console.ReadLine();

if (students == "1") {
    for (int i = 0; i < studentsG1.Length; i++)
    {
        Console.WriteLine("The Students in G1 are:" + studentsG1[i]);
    }
} else if (students == "2") {
    for (int i = 0; i < studentsG2.Length; i++)
    {
        Console.WriteLine("The Students in G2 are:" + studentsG2[i]);
    }
} else
    Console.WriteLine("Your input is not valid");


